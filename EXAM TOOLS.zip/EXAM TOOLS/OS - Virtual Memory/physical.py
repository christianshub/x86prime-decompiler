
def print_phy_table(addy_bin, PPN_num, PPO_num, CT_num, CI_num, CO_num):

    print("         ", end = '')
    for i in addy_bin:
        print(i, end = '')
    
    # ===========================
    print("")
    print("PPN_num  ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) < PPN_num):
            print("-", end = '')
    
    # ===========================
    print("")
    print("CT_num   ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) < CT_num):
            print("-", end = '')
        else:
            print(" ", end = '')  

    # ===========================
    print("")
    print("")
    print("PPO_num  ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) >= PPN_num):
            print("-", end = '')
        else:
            print(" ", end = '')

    # ===========================
    print("")
    print("CI_num   ", end = '')
    for i in range(len(addy_bin)):
        if (i >= CT_num and i < CT_num + CI_num):
            print("-", end = '')
        else:
            print(" ", end = '')    
    # ===========================
    print("")
    print("CO_num   ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) >= len(addy_bin) - CO_num):
            print("-", end = '')
        else:
            print(" ", end = '')    
    # ===========================

    print("")

# addy = "0x354"
# addy_bin = "001101010100"

# print_phy_table(addy_bin, 6, 6, 6, 4, 2)


def CT_binary(addy_bin, CT_num):

    str = ""
    for i in range(len(addy_bin)):
        if (i < CT_num):
            str = str + addy_bin[i]
    return str

# addy_bin = "001101010100"
# test = CT_binary(addy_bin, 6)
# print(test)

def CI_binary(addy_bin, CI_num, CT_num):

    str = ""
    for i in range(len(addy_bin)):
        if (i >= CT_num) and (i < CT_num + CI_num):
            str = str + addy_bin[i]
    return str


# addy_bin = "001101010100"
# test = CI_binary(addy_bin, 4, 6)
# print(test)

def CO_binary(addy_bin, CO_num):
    str = ""
    for i in range(len(addy_bin)):
        if (i >= len(addy_bin) - CO_num):
            str = str + addy_bin[i]
    return str


# addy_bin = "001101010100"
# test = CO_binary(addy_bin, 2)
# print(test)



