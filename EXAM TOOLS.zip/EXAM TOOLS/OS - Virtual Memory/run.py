import numpy as np
from helpers import *
from tables import *
from physical import *

VA_bits_width = 15
PA_bits_width = 13

virtual_addy_hex = "0x0001"
virtual_addy_bin = bin(int(virtual_addy_hex, 16))[2:].zfill(VA_bits_width)

pageSize = 128
page_table_PTEs = 8

TLB_way = 3
TLB_sets = 4 
TLB_total_entries = 12

cache_line_size = 4 # used for PA's!

VPO = int(np.log2(pageSize))
VPN = VA_bits_width - VPO

print("==================================")
print("INFO: \n")
print("Virtual addresses are ({0}) bits wide".format(VA_bits_width))
print("Page size: {0}, log2({0}) is VPO: {1}".format(pageSize, int(np.log2(pageSize))))
print("Since VPO is ({0}), VPN is ({1}-{0} = {2})".format(VPO, VA_bits_width, (VA_bits_width-VPO)))
print("==================================")
print("TABLE REPRESENTATION: \n")
print_table(virtual_addy_bin, VPN, VPO, TLB_sets)

print("\n==============================")
print("Calculations: \n")

VPO_bin = count_VPO_binary(virtual_addy_bin, VPO)
print("VPO: {0} (bin), {1} (hex), {2} (dec)".format(VPO_bin, hex(int(VPO_bin, 2)), int(VPO_bin, 2)))

VPN_bin = count_VPN_binary(virtual_addy_bin, VPN)
print("VPN: {0} (bin), {1} (hex), {2} (dec)".format(VPN_bin, hex(int(VPN_bin, 2)), int(VPN_bin, 2)))

print("TLBT num: {0}, TLBI num: {1}".format(int(TLBT(VPN, TLB_sets)), int(TLBI(VPN, TLB_sets))))


TLBT_binary = count_TLBT_binary(count_VPN_binary(virtual_addy_bin, VPN), TLB_sets)
print("TLBT: {0} (bin), {1} (hex), {2} (dec)".format(TLBT_binary.zfill(int(TLBT(VPN, TLB_sets))), hex(int(TLBT_binary, 2)), int(TLBT_binary, 2)))

TLBI_binary = count_TLBI_binary(count_VPN_binary(virtual_addy_bin, VPN), TLB_sets)
print("TLBI: {0} (bin), {1} (hex), {2} (dec)".format(TLBI_binary.zfill(int(TLBI(VPN, TLB_sets))), hex(int(TLBI_binary, 2)), int(TLBI_binary, 2)))


print("=====================")
print("MMU now extracts the VPN from the virtual address and checks with the TLB to see if it has cached a copy of PTE, if not, it will go to page table! \n")

PPN_tlb = get_PPN_from_TBL(all_TLB_sets, int(TLBI_binary, 2), int(TLBT_binary, 2))
PPN_pTable = get_PPN_from_page_table(all_tables, int(VPN_bin, 2))

print("==================================")
print("FINAL VM RESULT")
print("==================================")

print("VPN: {0}".format(hex(int(VPN_bin, 2))))
print("TLB index (TLBI): {0}".format(hex(int(TLBI_binary, 2))))
print("TLB tag (TLBT): {0}".format(hex(int(TLBT_binary, 2))))

PPN = "--"
if (type(PPN_tlb) != str):
    can_calculate_physical_addy = True
    print("TLB hit: Y")
    print("Page fault: N")
    print("PPN: {0}".format(hex(PPN_tlb)))
    PPN = PPN_tlb
elif (type(PPN_pTable) != str):
    can_calculate_physical_addy = True
    print("TLB hit: N")
    print("Page fault: N")
    print("PPN: {0}".format(hex(PPN_pTable)))
    PPN = PPN_pTable
else:
    print("Page fault!")
    print("No PPN")

print("==================================")
print("PHYSICAL ADDRESS TRANSLATION")
print("==================================")

if (type(PPN) != str):


    PPO = int(VPO_bin, 2)
    PPO_num = int(np.log2(pageSize))
    PPN_num = PA_bits_width - PPO_num
    CO_num = int(np.log2(cache_line_size)) # The L1 d-cache is physically addressed and direct mapped, with a 4-byte line size and 16 total sets.
    CI_num = PPO_num - CO_num
    CT_num = PA_bits_width - CO_num - CI_num
 
    physical_address = concatHex(PPN, PPO)
    
    physical_addy_bin = bin(int(hex(physical_address), 16))[2:].zfill(PA_bits_width)

    print("PA: ", hex(physical_address))
    print("PPO: {0}, PPO_num: {1}".format(hex(PPO), PPO_num))
    print("PPN: {0}, PPN_num: {1}".format(hex(PPN), PPN_num))
    print("CO_num: {0}, CI_num: {1}, CT_num: {2}".format(CO_num, CI_num, CT_num))
    print("CO_bin: {0}, CI_bin: {1}, CT_bin: {2}".format(CO_binary(physical_addy_bin, CO_num), CI_binary(physical_addy_bin, CI_num, CT_num), CT_binary(physical_addy_bin, CT_num)))
    print("CO_hex: {0}, CI_hex: {1}, CT_hex: {2}".format(hex(int(CO_binary(physical_addy_bin, CO_num), 2)), hex(int(CI_binary(physical_addy_bin, CI_num, CT_num), 2)), hex(int(CT_binary(physical_addy_bin, CT_num),2))))

    print("=========================")
    print("TABLE REPRESENTATION")

    print_phy_table(physical_addy_bin, PPN_num, PPO_num, CT_num, CI_num, CO_num)

    print("Now read the Cache table")

else:
    print("No bits of physical address could be calculated")