# ==================================================================================
# PAGE TABLE
# ==================================================================================

#           VPN  PPN   Valid             
 
table_00 = [0x00, 0x28, 0x1]
table_01 = [0x01, "--", 0x0]
table_02 = [0x02, 0x33, 0x1]
table_03 = [0x03, 0x02, 0x1]
table_04 = [0x04, "--", 0x0]
table_05 = [0x05, 0x16, 0x1]
table_06 = [0x06, "--", 0x0]
table_07 = [0x07, "--", 0x0]
table_08 = [0x08, 0x13, 0x1]
table_09 = [0x09, 0x17, 0x1]
table_0A = [0x0A, 0x09, 0x1]
table_0B = [0x0B, "--", 0x0]
table_0C = [0x0C, "--", 0x0]
table_0D = [0x0D, 0x2D, 0x1]
table_0E = [0x0E, 0x11, 0x1]
table_0F = [0x0F, 0x0D, 0x1]

all_tables = [table_00, table_01, table_02, table_03,
              table_04, table_05, table_06,
              table_07, table_08, table_09,
              table_0A, table_0B, table_0C,
              table_0D, table_0E, table_0F]

def print_page_table(page_tables):

    print("==============================")
    print("PAGE TABLE (only the first 16 PTEs are shown)\n")

    for tables in page_tables:
        for i in range(len(tables)):
            if (i == 0):
                # print("VPN:)
                print("VPN: {0} | ".format(hex(tables[i])), end = '')
            elif (i == 1):
                if (type(tables[i]) != str):
                    # align
                    if (tables[i] < 16):
                        print("PPN: {0}  | ".format(hex(tables[i])), end = '')
                    else:
                        print("PPN: {0} | ".format(hex(tables[i])), end = '')
                else:
                    print("PPN:  --  | ", end = '')
            elif (i == 2):
                    print("Valid: {0} | ".format(tables[i]), end = '')
        
        print("")

# print_page_table(all_tables)


def get_PPN_from_page_table(page_tables, VPN):

    print("VPN: {0}".format(VPN))

    for i in range (len(page_tables)):
        if (i == VPN):
            if (page_tables[VPN][2] == 1):
                print("table: {0}, PPN: {1}, valid: {2}".format(page_tables[VPN][0], hex(page_tables[VPN][1]), page_tables[VPN][2]))
                return page_tables[VPN][1]
            print("page fault! The kernel must page in the appropriate page and rerun the load instruction.")
            return "--"
    print("given VPN number doesn't match the VPN page_table number")
    return "--"

# get_PPN_from_page_table(all_tables, 8)

# ==================================================================================
# TLB TABLE
# ==================================================================================

# TLB: 4 sets, 16 entries, 4-way set associative

#            TAG    PPN  Valid
set0_way0 = [0x03, "--", 0x0]
set0_way1 = [0x09, 0x0D, 0x1]
set0_way2 = [0x00, "--", 0x0]
set0_way3 = [0x07, 0x02, 0x1]
set0 = [set0_way0, set0_way1, set0_way2, set0_way3]

set1_way0 = [0x03, 0x2D, 0x1] 
set1_way1 = [0x02, "--", 0x0] 
set1_way2 = [0x04, "--", 0x0]
set1_way3 = [0x0A, "--", 0x0]
set1 = [set1_way0, set1_way1, set1_way2, set1_way3]

set2_way0 = [0x02, "--", 0x0]
set2_way1 = [0x08, "--", 0x0]
set2_way2 = [0x06, "--", 0x0]
set2_way3 = [0x03, "--", 0x0]
set2 = [set2_way0, set2_way1, set2_way2, set2_way3]

set3_way0 = [0x07, "-.", 0x0]
set3_way1 = [0x03, 0x0D, 0x1]
set3_way2 = [0x0A, 0x34, 0x1]
set3_way3 = [0x02, "--", 0x0]
set3 = [set3_way0, set3_way1, set3_way2, set3_way3]

all_TLB_sets = [set0, set1, set2, set3]

def print_TLB_table(all_sets):
    for i in range(len(all_sets)):
        print("set {0}: {1}".format(i, all_sets[i]))

# print_TLB_table(all_TLB_sets)

""" 
To begin, the MMU extracts the VPN (0x0F) from the virtual address and
checks with the TLB to see if it has cached a copy of PTE 0x0F from some previous
memory reference. The TLB extracts the TLB index (0x03) and the TLB tag (0x3)
from the VPN, hits on a valid match in the second entry of set 0x3, and returns
the cached PPN (0x0D) to the MMU.
"""
def get_PPN_from_TBL(all_sets, TLB_index, TLB_tag):

    # print("relevant set: {0}, TLB_index: {1}, TLB_tag {2}".format(all_sets[TLB_index], TLB_index, TLB_tag))

    relevantSet = all_sets[int(TLB_index)]

    for i in range(len(relevantSet)):
        if (relevantSet[i][0] is TLB_tag):
            # print("Found! (Way: {0}, Tag: {1}, PPN: {2}, valid: {3}".format(i, relevantSet[i][0], hex(relevantSet[i][1]), relevantSet[i][2]))
            # print("Return PPN: {0} to MMU".format(hex(relevantSet[i][1])))
            # print(type(hex(relevantSet[i][1])))
        
            return relevantSet[i][1]
    
    print("Miss! the MMU need to fetch the PTE from main memory. Use page table! Return \"--\" ")
    return "--"

# get_PPN_from_TBL(all_TLB_sets, 0x3, 0x3)

""" 
The MMU now
has everything it needs to form the physical address. It does this by concatenating
the PPN (0x0D) from the PTE with the VPO (0x14) from the virtual address, which
forms the physical address (0x354)

"""
        
