import numpy as np

# hex(concatHex(a, b))
def concatHex(a, b):
    sizeof_b = 0

    # get size of b in bits
    while((b >> sizeof_b) > 0):
        sizeof_b += 1

    # align answer to nearest 4 bits (hex digit)
    sizeof_b += sizeof_b % 4

    return (a << sizeof_b) | b

# VA_bits_width = 14
# PA_bits_width = 12

# virtual_addy_hex = "0x03d4"
# addybin = bin(int(virtual_addy_hex, 16))[2:].zfill(VA_bits_width)

    
# print_table(addybin, 8, 6)


def count_VPN_binary(addy_bin, VPN):

    str = ""
    for i in range(len(addy_bin)):
        if (i < VPN):
            str = str + addy_bin[i]
    
    return str

# print("")
# VPN_bin = count_VPN_binary(addybin, 8)
# print("VPN: {0} (bin), {1} (hex), {2} (dec)".format(VPN_bin, hex(int(VPN_bin, 2)), int(VPN_bin, 2)))

def count_VPO_binary(addy_bin, VPO):

    str = ""
    for i in range(len(addy_bin)):
        if (i >= (len(addy_bin) - VPO) ):
            str = str + addy_bin[i]
    
    return str

# VPO_bin = count_VPO_binary(addybin, 6)
# print("VPO: {0} (bin), {1} (hex), {2} (dec)".format(VPO_bin, hex(int(VPO_bin, 2)), int(VPO_bin, 2)))


def count_TLBT_binary(VPN_addy_bin, sets):
    str = ""
    for i in range(len(VPN_addy_bin)):
        if (i < (len(VPN_addy_bin) - np.log2(sets)) ):
            str = str + VPN_addy_bin[i]
    
    return str

def count_TLBI_binary(VPN_addy_bin, sets):
    str = ""
    for i in range(len(VPN_addy_bin)):
        if (i >= (len(VPN_addy_bin) - np.log2(sets)) ):
            str = str + VPN_addy_bin[i]
    
    return str

# TLBT_binary = count_TLBT_binary(count_VPN_binary(addybin, 8), 4)
# print("TLBT: {0} (bin), {1} (hex), {2} (dec)".format(TLBT_binary.zfill(6), hex(int(TLBT_binary, 2)), int(TLBT_binary, 2)))

# TLBI_binary = count_TLBI_binary(count_VPN_binary(addybin, 8), 4)
# print("TLBI: {0} (bin), {1} (hex), {2} (dec)".format(TLBI_binary, hex(int(TLBI_binary, 2)), int(TLBI_binary, 2)))


""" 
The TLB is X-way set associative with Y total entries.

Example:
The TLB is virtually addressed using the bits of the VPN. Since the TLB
has four sets, the 2 low-order bits of the VPN serve as the set index (TLBI).
The remaining 6 high-order bits serve as the tag (TLBT) that distinguishes
the different VPNs that might map to the same TLB set.
"""
# Tag (high order bits) 
def TLBT(VPN, sets):
    return VPN - np.log2(sets)
 
# Index (low order bits)
def TLBI(VPN, sets):
    return np.log2(sets)

def TLBI_binary(TLBT_addy, TLBT_num):

    str = ""
    for i in range(len(TLBT_addy)):
        if (i >= (len(addy_bin) - 6) ):
            str = str + addy_bin[i]
    
    return str


def print_table(addy_bin, VPN, VPO, sets):

    tlbi = np.log2(sets)
    tlbt = VPN - tlbi

    print("     ", end = '')
    for i in addy_bin:
        print(i, end = '')
    
    print("")
    print("VPN  ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) < VPN):
            print("-", end = '')
    
    print("")
    print("VPO  ", end = '')
    for i in range(len(addy_bin)):
        if (int(i) >= VPN):
            print("-", end = '')
        else:
            print(" ", end = '')


    print("")
    print("TLBI ", end = '')
    for i in range(VPN):
        if (i >= tlbt):
            print("-", end = '')
        else:
            print(" ", end = '')

    print("")
    print("TLBT ", end = '')
    for i in range(VPN):
        if (i < tlbt):
            print("-", end = '')
        else:
            print(" ", end = '')

    print("")