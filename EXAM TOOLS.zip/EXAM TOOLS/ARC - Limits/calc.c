#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <float.h>

long boundary(long, long);

int main() {
    printf("x: min, y: min: %ld\n", boundary(LONG_MIN,LONG_MIN));
    printf("x: max, y: max: %ld\n", boundary(LONG_MAX,LONG_MAX));
    printf("x: min, y: max: %ld\n", boundary(LONG_MIN,LONG_MAX));
    printf("x: max, y: min: %ld\n", boundary(LONG_MAX,LONG_MIN));
}


long boundary(long x, long y) {

    printf("===============\n");
    printf("x: %ld \n", x);
    printf("y: %ld \n", y);
    printf("(x < y): %d \n", (x < y));
    printf("((-x) > (-y)): %d \n", ((-x) > (-y)));
    return ((x < y) == ((-x) > (-y)));
}