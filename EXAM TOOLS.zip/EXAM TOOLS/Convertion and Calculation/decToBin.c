void dec2bin(int c)
{
   int i = 0;
   for(i = 3; i >= 0; i--){
     if((c & (1 << i)) != 0){
       verbose_print(("1"));
     }else{
       verbose_print(("0"));
     } 
   }
}