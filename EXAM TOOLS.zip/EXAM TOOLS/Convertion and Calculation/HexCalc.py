# Calculate (%reg, %reg, number) = (%reg + (%reg*number)
def addition(hex1, hex2, number):
    a = int(hex1, 16)
    b = int(hex2, 16)

    res = a + (b * number)
    print(hex(res))

addition("0x100", "0x3", 4)
