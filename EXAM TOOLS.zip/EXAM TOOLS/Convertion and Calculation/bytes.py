# Convert KB to bytes 
def kilobytes_to_bytes(KB_size):
    return KB_size * 1024

print(kilobytes_to_bytes(2))
