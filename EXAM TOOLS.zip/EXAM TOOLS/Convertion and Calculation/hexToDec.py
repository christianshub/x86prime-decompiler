s = "0x12" #input
i = int(s, 16)
print(i)