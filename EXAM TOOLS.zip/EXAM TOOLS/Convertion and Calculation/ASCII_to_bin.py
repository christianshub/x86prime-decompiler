import binascii

input = 'M' # input here
print(bin(int(binascii.hexlify(input), 16))[2:].zfill(8))
