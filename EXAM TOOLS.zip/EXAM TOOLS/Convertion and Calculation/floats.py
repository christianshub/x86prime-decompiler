#####################################################
# BINARY TO FLOAT
from ast import literal_eval

float_str = "-0b101010101" # INSERT (no '0b' prefix)
result = float(literal_eval(float_str))
print("binary to float", result)

#####################################################
# FLOAT TO BINARY

import bitstring
f1 = bitstring.BitArray(float=-341.0, length=32)
print("float to binary", f1.bin, "float to hex", f1)

