input = int('11', 2)
print(input)
