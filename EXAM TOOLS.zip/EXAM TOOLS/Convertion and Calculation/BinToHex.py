def binToHex(binString):
    return hex(int(binString,2))

binString = "0011000"
print(binToHex(binString))
