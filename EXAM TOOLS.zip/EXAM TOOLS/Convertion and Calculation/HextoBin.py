# Convert hex to binary (with size)
def hexToBin(size, hexadecimal):
    return bin(int(hexadecimal, 16))[2:].zfill(size)

""" Example: """
print(hexToBin(10, "0x1"))