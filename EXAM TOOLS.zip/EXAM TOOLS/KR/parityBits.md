1) Oversæt hvert bogstav til binær tal
2) Skriv det ned under hinanden
3) Hvis even parity: lige = 0, ulige = 1
   Hvis odd parity: lige = 1, ulige = 0
4) EKSEMPEL:

Odd parity (lige = 1, ulige = 0)

E   0 1 0 0 0 1 0 1 | 0
X   0 1 0 1 1 0 0 0 | 0
A   0 1 0 0 0 0 0 1 | 1 
M   0 1 0 0 1 1 0 1 | 1
------------------
    0 1 1 0 1 1 1 0