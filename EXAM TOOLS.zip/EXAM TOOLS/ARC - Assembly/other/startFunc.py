def startfunc(string):
    if (":" in string) and not (".L" in string):
        print("function", end = "")
        # print("\n=======================================================================",end = "")
        # print(string.strip(), end = "")  