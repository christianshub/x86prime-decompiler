from cb.cba  import cba
from cb.cbae import cbae
from cb.cbb  import cbb
from cb.cbbe import cbbe 
from cb.cbe  import cbe
from cb.cbg  import cbg
from cb.cbge import cbge
from cb.cbl  import cbl
from cb.cble import cble
from cb.cbne import cbne

def compareBranch(string):
    cba(string)
    cbae(string) 
    cbb(string)
    cbbe(string)
    cbe(string) 
    cbg(string)
    cbge(string)
    cbl(string) 
    cble(string) 
    cbne(string)


