def cbe(string):
    
    if "cbe" in string:
        s = string.split(",")[0].split("cbe")[1].strip()
        d = string.split(",")[1].strip()
        p = string.split(",")[2].strip()
        print("if {0} == {1} then jump to {2}".format(s, d, p), end = "")    

# string = "cbe %rsi, %rax, .L3"
# cbe(string)