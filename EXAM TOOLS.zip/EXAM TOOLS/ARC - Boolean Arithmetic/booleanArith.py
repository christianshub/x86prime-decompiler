A = 2 # Don't touch
B = 1 # Don't touch

###########################################
# Write the question here, like below:
statement = (A & ~B) == ((A ^ B) & A) 
###########################################

print(statement) # Don't touch
 