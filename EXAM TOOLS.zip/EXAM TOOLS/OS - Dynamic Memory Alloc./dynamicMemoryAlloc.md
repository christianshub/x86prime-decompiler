# Question 2.4.1 from re-exam april 17th, 2018 (Jens)

Vi skal free'e addressen 0x200b010. Dette er addressen på det første "element" i det område, vi prøver at free, så vi skal tage udgangspunkt i dette områdes "header", hvilket er den "kasse", der er lige nedenunder. Den indeholder 0x0000001b; omskrevet til binær er det 0...00011011.

Siden at opgaven skriver at det er de 29 højereordensbits, der indikerer størrelsen på området, opdeler vi vores binære tal således: 0...00011|011. Kigger vi på den venstre del (altså højereordensbits) kan vi se at der står tallet 3, så vores område fylder 3 memory "blocks" eller 3x8 bytes (husk at opgaven skriver at "...the size is a multiple of eight bytes...").

Kigger man på kasserne i figuren, kan man se, at de derimod kun fylder 4 bytes. Der går altså 2 kasser på en memory "block", så vores "område" fylder 3x2=6 kasser. Man kan se, at det område, der er mellem 0x200b00c og 0x200b020, som vores header og footer udspænder (de er identiske), også fylder 6 kasser!

Nu kan vi altså gå i gang med den egentlige "free'ing". Det fremgår af opgaven, at bit 0 og bit 1 i header/footer indikerer, om dette memory område eller det forrige er allokeret eller ej. Det er altså (umiddelbart!) tilstrækkeligt bare at opdatere lavereordensbits i de relevante headers/footers.

Dog skal vi nu være opmærksomme på en anden egenskab for vores dynamic storage, der også står i opgaven: "immediate coalescing"! Det betyder, at hvis vi free'er et memory område, så skal vi også smække det sammen med naboområder, der også er free. Vi kan se ud fra headers/footers på de memory områder, der er over/under vores oprindelige område, at området under er free (lavereordensbits er 010), og området over er allokeret (lavereordensbits er 011). Vi skal altså "joine" vores oprindelige område (det, som har header/footer 0x0000001b) og det lige under (det, som har header/footer 0x00000012).

Vi beregner først størrelsen på det nye område. Vi læser bare på figuren, og kan se, at der fra og med den nederste header til og med den øverste footer er 10 kasser, hvilket er 10/2=5 memory blocks. Vores højereordensbits skal altså være 0...00101.
Nu til de 3 lavereordensbits. Vi har lige free'et området, så det 0. bit skal også være 0. Vi ved også fra vores nederste memory område (0x00000012), at det (hypotetiske) område under denne er allokeret (det fremgår af at det 1. bit er 1), så vi skal beholde dette 1. bit lig 1. Det 2. bit skal altid være 0, så der er ikke noget der.

Siden at vi joiner to områder, er det kun den laveste header (nu på addresse 0x200affc) og den højeste footer (nu på addresse 0x200b020), vi skal opdatere. Disse sætter vi til 0...00101|010 = 0x0000002a. De to "midterste" header/footer (addresse 0x200b008 og 0x200b00c) behøver vi ikke at opdatere, da vi nu alligevel har joinet området til ét stort område.

Det sidste vi skal gøre er at opdatere det 2. bit i header/footer i området efter (addresse 0x200b024 til 0x200b030) for at indikere, at det forrige område ikke længere er allokeret, men freed. Dette bringer header/footer fra 0x00000013 til 0x00000011.