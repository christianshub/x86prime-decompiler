import numpy as np
from functions import *

print("==============================================================================================")
print("GIVEN INFORMATION: \n")

# ==== START INSERT
CACHE_SIZE_BYTES = 2048     # ... "associative data cache of XX bytes/kilobytes"
BLOCK_SIZE_BYTES = 64       # ... "Cache have a block size of XX bytes/kilobytes"
LINES_PER_SET = 2           # DIRECT = 1, 2_WAY = 2, 4_WAY = 4, 8_WAY = 8

ADDRESS_SIZE_BITS = 16      # Length of table
ADDRESS_HEX = "0x0004"      # Reference to address
STREAM = ["0xA000", "0xF020", "0xFF00", "0xFF0C", "0x0018", "0xF0A4", "0xF004"]
# ==== END INSERT 

ADDRESS_BIN = hexToBin(ADDRESS_SIZE_BITS, ADDRESS_HEX)

print("ADDRESS:               {0} (hex), {1} (bin), {2} (bitsize)".format(ADDRESS_HEX, ADDRESS_BIN, ADDRESS_SIZE_BITS))
print("CACHE_SIZE_BYTES:     ", CACHE_SIZE_BYTES)
print("BLOCK_SIZE_BYTES:     ", BLOCK_SIZE_BYTES)
print("CACHE ASSOCIATIVATIVE: {0}-WAY".format(LINES_PER_SET))

print("\n==============================================================================================")
print("CALCULATIONS: \n")
# tag: 6, index: 4, offset: 6

def get_info():

    # OFFSET BITS
    offset_bits_num = get_block_offset_bits_num(BLOCK_SIZE_BYTES)

    # SET INDEX BITS
    sets = get_sets(CACHE_SIZE_BYTES, BLOCK_SIZE_BYTES, LINES_PER_SET)
   
    index_bits_num = get_index_bits_num(sets)

    # TAG BITS
    tag_bits_num = get_tag_bits_num(ADDRESS_SIZE_BITS, index_bits_num, offset_bits_num)

    offset_bin = get_block_offset_bits_bin(ADDRESS_BIN, offset_bits_num)
    index_bin = get_index_bits_bin(ADDRESS_BIN, offset_bits_num, index_bits_num)
    tag_bin = get_tag_bits_bin(ADDRESS_BIN, tag_bits_num)

    print("Total amount of sets: {0} \n".format(int(sets)))
    
    print("Inital address: {0}".format(ADDRESS_HEX))
    print("tag_bits_num: {0}, index_bits_num: {1}, offset_bits_num: {2}".format(tag_bits_num, index_bits_num, offset_bits_num))
    print("tag_bits_bin: {0}, index_bits_bin: {1}, offset_bits_bin: {2}".format(tag_bin, index_bin, offset_bin))
    print("tag_bits_hex: {0}, index_bits_hex: {1}, offset_bits_hex: {2}".format(binToHex(tag_bin), binToHex(index_bin), binToHex(offset_bin)))
 
    print("\n\n")

    print("Compare ref with other addy's to see if there is a hit or miss")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("ADDR   |    TAG    |   SET   |   OFFSET")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    
    addy = hexToBin(ADDRESS_SIZE_BITS, ADDRESS_HEX)
    offset = get_block_offset_bits_bin(addy, offset_bits_num)
    index = get_index_bits_bin(addy, offset_bits_num, index_bits_num)
    tag = get_tag_bits_bin(addy, tag_bits_num)

    print(ADDRESS_HEX + "(ref)", tag, "      ", index, "     ", offset)
    print("**********************************************************************************************")



    for i in STREAM:

        addy = hexToBin(ADDRESS_SIZE_BITS, i)
        offset = get_block_offset_bits_bin(addy, offset_bits_num)
        index = get_index_bits_bin(addy, offset_bits_num, index_bits_num)
        tag = get_tag_bits_bin(addy, tag_bits_num)

        print(i, "    ", tag, "      ", index, "     ", offset)
        print("-----------------------------------------------------------------------------------------------")


    print("\n\n==============================================================================================")
    print("Now manually draw a box looking like this to see if there are hit's or misses: \n")

    print("| Set | LRU | ", end = "")
    for i in range(LINES_PER_SET):
        print("V | Tag | ", end = "")
    print("")
    for i in range(int(sets)):
        if (i < 4):
            print("|",bin(i)[2:].zfill(2), " |")
        elif (i < 7):
            print("| ... |")

get_info()
