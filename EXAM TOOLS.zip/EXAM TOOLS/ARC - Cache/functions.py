import numpy as np

#* Convert hex number (address) to binary with a given size
def hexToBin(size, hexadecimal):
    return bin(int(hexadecimal, 16))[2:].zfill(size)

def binToHex(binString):
    return hex(int(binString,2))

#! =================================================
#! 

#* E: Lines per set
def get_lines_per_set(cacheSize, blockSize, sets):
    return cacheSize/(blockSize*sets)

#* C: Cache size (bytes)
def get_cache_size(blockSize, linesPrSet, sets):
    return (blockSize*linesPrSet*sets)

#* B: Block size (bytes)
def get_blocksize(cacheSize, linesPrSet, sets):
    return cacheSize/(linesPrSet*sets)

#* S: Number of sets
def get_sets(cacheSize, blockSize, linesPrSet):
    return cacheSize/(blockSize*linesPrSet)
#! =================================================
#! 

#* s: number of set index bits (number)
def get_index_bits_num(sets):
    return int(np.log2(sets))

#* b: number of block offset bits (number)
def get_block_offset_bits_num(blockSize):
    return int(np.log2(blockSize))

#* t: number of tag bits (number)
def get_tag_bits_num(addy_num, index_bits, offset_bits):
    return addy_num - (index_bits + offset_bits)

#! =================================================
#! 

#* set index
def get_block_offset_bits_bin(addy_bin, offset_num):
    str = ""
    for i in range(len(addy_bin)):
        if (i >= (len(addy_bin) - offset_num)):
            str = str + addy_bin[i]

    return str

# ofs = get_block_offset_bits_bin("123456789ABCDEFG", 6)
# print(ofs)

def get_index_bits_bin(addy_bin, offset_num, index_num):
    str = ""
    for i in range(len(addy_bin)):
        if (i >= (len(addy_bin) - offset_num - index_num)) and (i < (len(addy_bin) - offset_num)):
            str = str + addy_bin[i]

    return str

# ofs = get_index_bits_bin("123456789ABCDEFG", 6, 4)
# print(ofs)

def get_tag_bits_bin(addy_bin, tag_num):
    str = ""
    for i in range(len(addy_bin)):
        if (i < tag_num):
            str = str + addy_bin[i]

    return str

# ofs = get_tag_bits_bin("123456789ABCDEFG", 6)
# print(ofs)