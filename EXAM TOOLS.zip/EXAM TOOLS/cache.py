i = 0
for i in range(0,11):
    print("i", i)
    print("")
    for j in range(i+1,11):
        print("j", j)
    print("")


